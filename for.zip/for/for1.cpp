#include<stdio.h>
int main()
{
	//variaveis
	int x;
	//Inicio do for
	for(x=10;x>0;x--)
	{
		printf("\nO Valor de x e: %d",x,"\n");
	}
}
